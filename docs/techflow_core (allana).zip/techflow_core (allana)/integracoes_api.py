import json
import re
import urllib.error
import urllib.request

TIMEOUT_SEGUNDOS = 5
VIACEP_URL = "https://viacep.com.br/ws/{cep}/json/"
AWESOMEAPI_USD_BRL_URL = "https://economia.awesomeapi.com.br/json/last/USD-BRL"


def _requisicao_json(url: str) -> tuple[bool, dict | list | str]:
    """Executa uma requisição HTTP GET e devolve o JSON descodificado ou erro."""
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "TechFlowCore/1.0"},
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SEGUNDOS) as resposta:
            if resposta.status != 200:
                return False, f"Erro HTTP {resposta.status} ao consultar o serviço."
            corpo = resposta.read().decode("utf-8")
            return True, json.loads(corpo)
    except urllib.error.HTTPError as exc:
        return False, f"Falha HTTP ({exc.code}) na consulta externa."
    except urllib.error.URLError:
        return False, "Falha de ligação à internet ou serviço indisponível."
    except TimeoutError:
        return False, "Tempo limite de pedido esgotado."
    except json.JSONDecodeError:
        return False, "Resposta inválida recebida da API."


def consultar_cep(cep: str) -> tuple[bool, dict | str]:
    """Consulta o ViaCEP e devolve dados de morada ou mensagem de erro."""
    digitos = re.sub(r"\D", "", cep or "")
    if len(digitos) != 8:
        return False, "CEP inválido. Indique 8 dígitos numéricos."

    ok, dados = _requisicao_json(VIACEP_URL.format(cep=digitos))
    if not ok:
        return False, str(dados)

    if not isinstance(dados, dict) or dados.get("erro"):
        return False, "CEP não encontrado na base do ViaCEP."

    return True, {
        "cep": dados.get("cep", f"{digitos[:5]}-{digitos[5:]}"),
        "logradouro": dados.get("logradouro", ""),
        "bairro": dados.get("bairro", ""),
        "cidade": dados.get("localidade", ""),
        "uf": dados.get("uf", ""),
    }


def consultar_cotacao_usd_brl() -> tuple[bool, dict | str]:
    """Consulta a AwesomeAPI para obter a cotação atual do dólar (USD-BRL)."""
    ok, dados = _requisicao_json(AWESOMEAPI_USD_BRL_URL)
    if not ok:
        return False, str(dados)

    if not isinstance(dados, dict) or "USDBRL" not in dados:
        return False, "Dados de cotação USD-BRL não encontrados na resposta."

    info = dados["USDBRL"]
    try:
        compra = float(info["bid"])
        venda = float(info["ask"])
    except (KeyError, TypeError, ValueError):
        return False, "Formato numérico inválido na cotação recebida."

    return True, {
        "par": "USD-BRL",
        "compra": compra,
        "venda": venda,
        "data_hora": info.get("create_date", ""),
    }


if __name__ == "__main__":
    print("ViaCEP:", consultar_cep("55150000"))
    print("AwesomeAPI:", consultar_cotacao_usd_brl())