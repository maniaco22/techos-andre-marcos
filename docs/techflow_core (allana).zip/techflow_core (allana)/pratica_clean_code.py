PRIORIDADE_ALTA = "ALTA"
PRIORIDADE_MEDIA = "MEDIA"
PRIORIDADE_BAIXA = "BAIXA"

PRAZO_URGENTE_DIAS = 1
PRAZO_ALTA_DIAS = 2
PRAZO_MEDIA_PADRAO_DIAS = 3
PRAZO_MEDIA_ESTENDIDO_DIAS = 4
PRAZO_BAIXA_DIAS = 5

LIMITE_ATRASO_ALTA = 10
LIMITE_ATRASO_MEDIA = 20


def calcular_prioridade_e_prazo(
    nivel_gravidade: int,
    dias_em_aberto: int,
    tipo_solicitacao: str,
) -> tuple[str, int]:
    """Calcula a prioridade e o prazo estimado (em dias) de um chamado."""
    solicitacao_normalizada = tipo_solicitacao.strip().lower()

    if nivel_gravidade == 1 or solicitacao_normalizada == "urgente":
        return PRIORIDADE_ALTA, PRAZO_URGENTE_DIAS

    if nivel_gravidade == 2:
        if dias_em_aberto > LIMITE_ATRASO_ALTA:
            return PRIORIDADE_ALTA, PRAZO_ALTA_DIAS
        return PRIORIDADE_MEDIA, PRAZO_MEDIA_PADRAO_DIAS

    if dias_em_aberto > LIMITE_ATRASO_MEDIA:
        return PRIORIDADE_MEDIA, PRAZO_MEDIA_ESTENDIDO_DIAS

    return PRIORIDADE_BAIXA, PRAZO_BAIXA_DIAS


if __name__ == "__main__":
    exemplos = [
        (2, 15, "normal"),
        (3, 5, "urgente"),
        (3, 25, "normal"),
    ]
    for gravidade, dias, tipo in exemplos:
        prioridade, prazo = calcular_prioridade_e_prazo(gravidade, dias, tipo)
        print(f"Prioridade: {prioridade} | Prazo: {prazo} dia(s)")