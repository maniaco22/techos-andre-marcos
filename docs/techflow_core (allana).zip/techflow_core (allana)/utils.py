import os
import re

PRIORIDADES_VALIDAS = ("BAIXA", "MEDIA", "ALTA")
STATUS_VALIDOS = ("ABERTA", "EM ANDAMENTO", "CONCLUIDA", "CANCELADA")


def limpar_tela() -> None:
    """Limpa o terminal no Windows ou em sistemas Unix/Linux/macOS."""
    comando = "cls" if os.name == "nt" else "clear"
    os.system(comando)


def exibir_cabecalho(titulo: str) -> None:
    """Exibe um cabeçalho formatado no terminal."""
    linha = "=" * 50
    print(f"\n{linha}")
    print(titulo.upper().center(50))
    print(linha)


def validar_texto_nao_vazio(valor: str, nome_campo: str = "Campo") -> tuple[bool, str]:
    """Valida se um texto não está vazio ou composto apenas por espaços."""
    if not isinstance(valor, str) or not valor.strip():
        return False, f"Erro: o campo '{nome_campo}' não pode ficar vazio."
    return True, valor.strip()


def validar_prioridade(prioridade: str) -> tuple[bool, str]:
    """Valida e normaliza a prioridade para BAIXA, MEDIA ou ALTA."""
    if not isinstance(prioridade, str):
        return False, "Erro: prioridade inválida."
    prioridade_limpa = prioridade.strip().upper()
    if prioridade_limpa not in PRIORIDADES_VALIDAS:
        return (
            False,
            f"Erro: prioridade inválida. Use: {', '.join(PRIORIDADES_VALIDAS)}.",
        )
    return True, prioridade_limpa


def formatar_cep(cep: str) -> tuple[bool, str]:
    """Valida e formata um CEP brasileiro no padrão 00000-000."""
    if not isinstance(cep, str):
        return False, "Erro: CEP inválido."
    digitos = re.sub(r"\D", "", cep)
    if len(digitos) != 8:
        return False, "Erro: o CEP deve conter exatamente 8 dígitos."
    return True, f"{digitos[:5]}-{digitos[5:]}"