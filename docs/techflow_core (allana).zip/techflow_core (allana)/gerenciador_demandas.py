from utils import (
    PRIORIDADES_VALIDAS,
    STATUS_VALIDOS,
    formatar_cep,
    validar_prioridade,
    validar_texto_nao_vazio,
)

demandas: list[dict] = []


def _buscar_indice_por_id(id_demanda: str) -> int:
    """Retorna o índice da demanda na lista pelo ID ou -1 se não existir."""
    id_limpo = id_demanda.strip()
    for indice, item in enumerate(demandas):
        if item["id"] == id_limpo:
            return indice
    return -1


def cadastrar_demanda(
    id_demanda: str,
    titulo: str,
    solicitante: str,
    prioridade: str,
    cep: str,
    cidade: str,
    status: str = "ABERTA",
) -> tuple[bool, str]:
    """Cadastra uma nova demanda bloqueando campos vazios e IDs duplicados."""
    ok_id, id_valido = validar_texto_nao_vazio(id_demanda, "id")
    if not ok_id:
        return False, id_valido

    if _buscar_indice_por_id(id_valido) != -1:
        return False, f"Erro: já existe uma demanda cadastrada com o ID '{id_valido}'."

    ok_titulo, titulo_valido = validar_texto_nao_vazio(titulo, "titulo")
    if not ok_titulo:
        return False, titulo_valido

    ok_sol, solicitante_valido = validar_texto_nao_vazio(solicitante, "solicitante")
    if not ok_sol:
        return False, solicitante_valido

    ok_prio, prioridade_valida = validar_prioridade(prioridade)
    if not ok_prio:
        return False, prioridade_valida

    ok_cep, cep_valido = formatar_cep(cep)
    if not ok_cep:
        return False, cep_valido

    ok_cidade, cidade_valida = validar_texto_nao_vazio(cidade, "cidade")
    if not ok_cidade:
        return False, cidade_valida

    ok_status, status_bruto = validar_texto_nao_vazio(status, "status")
    if not ok_status:
        return False, status_bruto
    status_valido = status_bruto.upper()
    if status_valido not in STATUS_VALIDOS:
        return False, f"Erro: status inválido. Use: {', '.join(STATUS_VALIDOS)}."

    nova_demanda = {
        "id": id_valido,
        "titulo": titulo_valido,
        "solicitante": solicitante_valido,
        "prioridade": prioridade_valida,
        "cep": cep_valido,
        "cidade": cidade_valida,
        "status": status_valido,
    }
    demandas.append(nova_demanda)
    return True, f"Demanda '{id_valido}' cadastrada com sucesso."


def listar_demandas() -> list[dict]:
    """Retorna todas as demandas armazenadas em memória."""
    return list(demandas)


def buscar_demandas(termo: str) -> list[dict]:
    """Busca demandas por ID exato ou trecho em título, solicitante, cidade ou status."""
    ok_termo, termo_limpo = validar_texto_nao_vazio(termo, "termo")
    if not ok_termo:
        return []
    termo_baixo = termo_limpo.lower()
    return [
        item
        for item in demandas
        if item["id"].lower() == termo_baixo
        or termo_baixo in item["titulo"].lower()
        or termo_baixo in item["solicitante"].lower()
        or termo_baixo in item["cidade"].lower()
        or termo_baixo in item["status"].lower()
    ]


def atualizar_status(id_demanda: str, novo_status: str) -> tuple[bool, str]:
    """Atualiza o status de uma demanda existente pelo ID."""
    ok_id, id_valido = validar_texto_nao_vazio(id_demanda, "id")
    if not ok_id:
        return False, id_valido

    ok_status, status_bruto = validar_texto_nao_vazio(novo_status, "status")
    if not ok_status:
        return False, status_bruto
    status_valido = status_bruto.upper()
    if status_valido not in STATUS_VALIDOS:
        return False, f"Erro: status inválido. Use: {', '.join(STATUS_VALIDOS)}."

    indice = _buscar_indice_por_id(id_valido)
    if indice == -1:
        return False, f"Erro: demanda '{id_valido}' não encontrada."

    demandas[indice]["status"] = status_valido
    return True, f"Status da demanda '{id_valido}' atualizado para '{status_valido}'."


def excluir_demanda(id_demanda: str) -> tuple[bool, str]:
    """Exclui uma demanda existente pelo ID."""
    ok_id, id_valido = validar_texto_nao_vazio(id_demanda, "id")
    if not ok_id:
        return False, id_valido

    indice = _buscar_indice_por_id(id_valido)
    if indice == -1:
        return False, f"Erro: demanda '{id_valido}' não encontrada."

    demandas.pop(indice)
    return True, f"Demanda '{id_valido}' excluída com sucesso."


if __name__ == "__main__":
    print(cadastrar_demanda("1", "Troca de tela", "Carlos", "ALTA", "55150000", "Belo Jardim"))
    print(cadastrar_demanda("1", "ID duplicado", "Ana", "BAIXA", "55150000", "Belo Jardim"))
    print(cadastrar_demanda("2", "", "Ana", "MEDIA", "55150000", "Belo Jardim"))
    print("Lista:", listar_demandas())
    print("Busca:", buscar_demandas("tela"))
    print(atualizar_status("1", "CONCLUIDA"))
    print(excluir_demanda("1"))
    print("Lista após exclusão:", listar_demandas())