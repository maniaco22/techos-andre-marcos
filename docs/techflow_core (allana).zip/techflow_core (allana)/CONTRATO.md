# Contrato Individual de Compromisso – Projeto TechFlow Core
**Responsável:** Allana Evelyn Alves Carvalho  
**Prazo Final:** 08/12/2026  

Eu, Allana, comprometo-me a cumprir rigorosamente as 5 regras abaixo para garantir a entrega completa e dentro do prazo:

1. **Constância Diária:** Dedicar pelo menos 1 hora focada por dia ao desenvolvimento e documentação do TechFlow Core, sem distrações.
2. **Entregas Incrementais:** Não acumular tarefas para a véspera; concluir cada etapa conforme os checkpoints do quadro Kanban.
3. **Validação Antecipada:** Submeter cada artefato (`REQUISITOS.md`, códigos e testes) para validação antes de avançar para a próxima etapa.
4. **Organização de Arquivos:** Manter todos os scripts e documentos salvos e organizados dentro da pasta `techflow_core (allana)`.
5. **Resolução Rápida de Bloqueios:** Ao encontrar qualquer erro técnico no Python ou no VS Code, testar soluções e buscar apoio imediatamente para não travar o cronograma.