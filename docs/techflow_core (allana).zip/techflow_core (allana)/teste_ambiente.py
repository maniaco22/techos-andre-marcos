﻿print("Ambiente TechFlow Core configurado com sucesso! Bem-vinda, Allana.")
