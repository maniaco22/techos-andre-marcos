# Kanban — TechFlow Core

## A Fazer / Em Revisão Final
- [ ] Revisão final de documentação e entrega antes do prazo de 08/12
- [ ] Validação com ligação à internet ativa das consultas reais no ViaCEP e na AwesomeAPI

## Em Progresso
- [ ] Refatoração final de reaproveitamento de validações entre módulos (`gerenciador_demandas.py` e `utils.py`) e teste ponta a ponta no `main.py`

## Concluído
- [x] Etapas 01–03: Onboarding, Requisitos e Kanban inicial
- [x] Etapa 04: Parecer de Arquitetura (`PARECER_ARQUITETURA.md`)
- [x] Etapa 05: Práticas de Clean Code (`pratica_clean_code.py`)
- [x] Etapa 06: Lógica CRUD de demandas (`gerenciador_demandas.py`)
- [x] Etapa 07: Funções utilitárias e validações (`utils.py`)
- [x] Etapa 08: Integração com APIs externas (`integracoes_api.py`) e menu CLI (`main.py`)