from gerenciador_demandas import (
    atualizar_status,
    buscar_demandas,
    cadastrar_demanda,
    excluir_demanda,
    listar_demandas,
)
from integracoes_api import consultar_cep, consultar_cotacao_usd_brl
from utils import exibir_cabecalho, limpar_tela


def _exibir_demandas(itens: list[dict]) -> None:
    """Mostra as demandas formatadas no terminal."""
    if not itens:
        print("\nNenhuma demanda encontrada.")
        return

    for item in itens:
        print(
            f"[{item['id']}] {item['titulo']} | Solicitante: {item['solicitante']} | "
            f"Prioridade: {item['prioridade']} | CEP: {item['cep']} ({item['cidade']}) | "
            f"Status: {item['status']}"
        )


def menu_principal() -> None:
    """Executa o menu interativo da aplicação CLI TechFlow Core."""
    while True:
        exibir_cabecalho("TechFlow Core - Menu")
        print("1. Cadastrar demanda")
        print("2. Listar demandas")
        print("3. Buscar demanda")
        print("4. Atualizar status")
        print("5. Excluir demanda")
        print("6. Consultar CEP (ViaCEP)")
        print("7. Consultar cotação USD-BRL (AwesomeAPI)")
        print("8. Limpar ecrã")
        print("0. Sair")

        opcao = input("\nEscolha uma opção: ").strip()

        if opcao == "1":
            exibir_cabecalho("Cadastrar Demanda")
            id_demanda = input("ID: ")
            titulo = input("Título: ")
            solicitante = input("Solicitante: ")
            prioridade = input("Prioridade (BAIXA / MEDIA / ALTA): ")
            cep = input("CEP: ")
            cidade = input("Cidade: ")
            _, mensagem = cadastrar_demanda(
                id_demanda=id_demanda,
                titulo=titulo,
                solicitante=solicitante,
                prioridade=prioridade,
                cep=cep,
                cidade=cidade,
            )
            print(f"\n{mensagem}")

        elif opcao == "2":
            exibir_cabecalho("Lista de Demandas")
            _exibir_demandas(listar_demandas())

        elif opcao == "3":
            exibir_cabecalho("Buscar Demanda")
            termo = input("Termo de busca (ID, título, solicitante, cidade ou status): ")
            _exibir_demandas(buscar_demandas(termo))

        elif opcao == "4":
            exibir_cabecalho("Atualizar Status")
            id_demanda = input("ID da demanda: ")
            novo_status = input("Novo status (ABERTA / EM ANDAMENTO / CONCLUIDA / CANCELADA): ")
            _, mensagem = atualizar_status(id_demanda, novo_status)
            print(f"\n{mensagem}")

        elif opcao == "5":
            exibir_cabecalho("Excluir Demanda")
            id_demanda = input("ID da demanda: ")
            confirmacao = input(f"Confirmar exclusão de '{id_demanda}'? (s/n): ").strip().lower()
            if confirmacao == "s":
                _, mensagem = excluir_demanda(id_demanda)
                print(f"\n{mensagem}")
            else:
                print("\nExclusão cancelada.")

        elif opcao == "6":
            exibir_cabecalho("Consulta ViaCEP")
            cep = input("CEP: ")
            ok, resultado = consultar_cep(cep)
            if ok and isinstance(resultado, dict):
                print(
                    f"\nCEP: {resultado['cep']}\n"
                    f"Morada: {resultado['logradouro']}\n"
                    f"Bairro: {resultado['bairro']}\n"
                    f"Cidade/UF: {resultado['cidade']} - {resultado['uf']}"
                )
            else:
                print(f"\nErro: {resultado}")

        elif opcao == "7":
            exibir_cabecalho("Cotação USD-BRL")
            ok, resultado = consultar_cotacao_usd_brl()
            if ok and isinstance(resultado, dict):
                print(
                    f"\nPar: {resultado['par']}\n"
                    f"Compra: R$ {resultado['compra']:.4f}\n"
                    f"Venda: R$ {resultado['venda']:.4f}\n"
                    f"Data/Hora: {resultado['data_hora']}"
                )
            else:
                print(f"\nErro: {resultado}")

        elif opcao == "8":
            limpar_tela()

        elif opcao == "0":
            print("\nA encerrar o TechFlow Core. Até breve!")
            break

        else:
            print("\nOpção inválida. Tente novamente.")


if __name__ == "__main__":
    menu_principal()