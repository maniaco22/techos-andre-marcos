# Engenharia de Requisitos – TechFlow Core

## 1. Requisitos Funcionais (RF)
* **RF01 – Cadastrar Demanda:** O sistema deve permitir cadastrar uma nova demanda informando título, descrição, categoria, prioridade, CEP de destino e data de registro.
* **RF02 – Listar Demandas:** O sistema deve listar todas as demandas cadastradas, exibindo ID, título, status atual e prazo.
* **RF03 – Buscar Demanda:** O sistema deve permitir buscar demandas específicas por ID, palavra-chave no título ou filtro por status.
* **RF04 – Atualizar Status:** O sistema deve permitir alterar o status de uma demanda (ex: *Aberta*, *Em Andamento*, *Aguardando Cotação*, *Concluída*).
* **RF05 – Excluir Demanda:** O sistema deve permitir excluir uma demanda existente mediante confirmação do usuário.
* **RF06 – Consultar CEP e Cotação:** O sistema deve consultar um CEP (via API como ViaCEP) para preencher o endereço automaticamente e calcular uma cotação estimada do serviço/frete.

## 2. Requisitos Não Funcionais (RNF)
* **RNF01 – Segurança:** O sistema deve validar todas as entradas do usuário (como formato numérico do CEP e campos obrigatórios) para evitar falhas de execução ou dados inválidos.
* **RNF02 – Integridade:** Os dados das demandas devem ser salvos em arquivo estruturado (JSON ou CSV), garantindo que não sejam perdidos ao fechar o programa.
* **RNF03 – Usabilidade:** O sistema deve apresentar menus claros no terminal, instruções objetivas e mensagens de confirmação ou erro fáceis de entender.
* **RNF04 – Desempenho:** As operações locais (cadastrar, listar, buscar, atualizar e excluir) devem responder em menos de 1 segundo, e a consulta externa de CEP deve ter limite (*timeout*) de até 5 segundos.
* **RNF05 – Portabilidade:** O sistema deve funcionar em Python 3.x sem exigir permissões de administrador na máquina local.